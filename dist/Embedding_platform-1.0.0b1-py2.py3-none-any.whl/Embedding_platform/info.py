"""
This file saves all broker.csv and pre_trained word embedding url.
"""


broker_url = 'https://query.data.world/s/1drcgirnk1cj4akj480o7x1bw'
table_parser = "marcusyyy/pre-trained-wordembedding"