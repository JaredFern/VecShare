"""
WordEmbeddingPlatform


This is a word embedding selection , query and download platform of which function is to
facilitate natural language processing researcher to use word embeddings more efficiently.

Associated with this platform is a broker-centered model. 

"""

from __future__ import absolute_import


__version__ = '1.0.0-beta.1'
